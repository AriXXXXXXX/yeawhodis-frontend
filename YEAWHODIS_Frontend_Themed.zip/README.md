# YEA WHO DIS Frontend (Live Version)
- Includes glowing Star of David Eye logo
- Fully themed, dark mode default
- Ready for Vercel deployment
